<!DOCTYPE html>
<html lang="en">
  <head>
    <title>UPSET</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="shortcut icon" href="<?=base_url('public/Logo.png');?>" type="image/x-icon">

    <link href="<?=base_url()?>/public/css/bootstrap-4.6.0/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?=base_url()?>/public/css/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?=base_url()?>/public/css/image-picker/image-picker.css" rel="stylesheet" type="text/css"/>
    <link href="<?=base_url()?>/public/css/alertify/alertify.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?=base_url()?>/public/css/alertify/themes/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="<?=base_url()?>/public/css/custom/change_password.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />

    <link href="<?=base_url()?>/public/css/custom/alert.css" rel="stylesheet">
    <link href="<?=base_url()?>/public/css/custom/styles.css" rel="stylesheet">

    <?php if(isset($css)):?>
      <?=echoFiles($css);?>
    <?php endif;?>
  </head>
  <body>
    <div class="bg-loader">
      <div class="se-pre-con"></div>
    </div>
    
    <!-- header section starts -->
    <section id="header">
      <div class="schoolWebsiteName landscape">
          <a href="<?=base_url();?>"><img src="<?=base_url()?>/public/Logo.png"></a>
          <h1> University of the Philippines High School Cebu</h1>
          <h2> Student Evaluation of Teachers</h2>
      </div>
      <div class="schoolWebsiteName portrait">
          <a href="<?=base_url();?>"><img src="<?=base_url()?>/public/Logo.png"></a>
          <h1> University of the Philippines <br>High School Cebu</h1>
          <h2> Student Evaluation of Teachers</h2>
      </div>
      
    </section>
    <!-- header section ends -->

    <!-- Sidebar Holder -->
    <div>
      <div class="d-flex" style="position: absolute; z-index: 1;">
        <nav id="sidebar" style="height: 109.5vh; overflow-y: scroll" class="active">
          <div class="sidebar-header">
            <div class="img bg-wrap text-center py-4" style="background-image: url(<?=base_url()?>public/samplecover.jpg);">
              <div class="user-logo">
                <img class="rounded-circle" src="<?=base_url() . $_SESSION['logged_user']['avatar_url']?>" style="margin-bottom: 2vh; width: 50%!important; height: auto !important;">
                <h3>Hi, <?=$_SESSION['logged_user']['first_name']?></h3>
              </div>
            </div>
          </div>

          <ul class="list-unstyled components">
            <li>
              <a href="<?=base_url('dashboard');?>"><i class="bi bi-house"></i> Dashboard</a>
              <?php if ($_SESSION['logged_user']['role'] === '2'):?>
                <a href="<?=base_url();?>/profile/student"><i class="bi bi-person-circle"></i>  Profile</a>
              <?php else:?>
                <a href="<?=base_url();?>/profile/admin"><i class="bi bi-person-circle"></i>  Profile</a>
              <?php endif;?>
              <a href="#settings" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="bi bi-gear-wide-connected"></i> Settings </a>
                  <ul class="collapse list-unstyled" id="settings">
                      <div class="d-flex flex-direction-row">
                        <p style="font-size: 1.3rem; margin-bottom: 0;">Allow Two-step Verification</p>
                        <div class="button-2f r" id="button-6">
                            <input type="checkbox" name="allow_verification" <?=set_checkbox('allow_verification', '', $_SESSION['logged_user']['allow_verify'])?> class="checkbox">
                            <div class="knobs">
                              <span class="dot"></span>
                            </div>
                            <div class="layer"></div>
                        </div>
                      </div>
                  </ul>
              <a href="#"><i class="bi bi-zoom-in"></i> About</a>
            </li>
          </ul>
          <ul class="list-unstyled CTAs components">
            <div class="evaluate">
                <a class="nav-link" id="evaluate" href="<?=base_url('subjects/student_subjects')?>"><button type="button"name="evaluate"><i class="bi bi-pencil-square" style="font-size:1.5rem;"></i>EVALUATE </button></a>
            </div>
          </ul>
          <ul class="list-unstyled CTAs">
            <div class="logout">
              <a class="nav-link" id="logout" href="<?=base_url('dashboard/logout')?>"><button type="button"  name="logOut"><i class="bi bi-box-arrow-left"></i> LOG OUT</button></a>
            </div>
          </ul>
        </nav>
        <!-- Page Content Holder -->
        <div class="navIcon">
          <div class="navbar-header">
            <button type="button" id="sidebarCollapse" class="navbar-btn"89>
              <i class="bi bi-list fa-2x"></i>
            </button>
          </div>
        </div>
      </div>
      <div class="wrapper align-items-stretch" id="main" style="height: 109.5">
        <?= $this->renderSection('content');?>
      </div>
    </div>
    <!-- footer section starts  -->

    <section id="footer" class="container-fluid" style="position: relative; z-index: 1000;">
      <div class="row-md-4">
        <div class="contactLinks">
          <h4 style="color:white; margin-top:2rem; font-family:OPTIMA; font-size:1.8rem; margin-bottom:1rem;"><i class="bi bi-person-circle" ></i> Contact Us:</h4>
          <div class="row">
            <div class="col-md-4 ">
              <div class="form-group footerContact ">
                <a href="https://upcebu.edu.ph" target="_blank" class="footerContact"> <i class="bi bi-globe"></i> UP Cebu</a>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <a href="mailto:lrc.upcebu@up.edu.ph" target="_blank"><i class="bi bi-envelope"></i> lrc.upcebu@up.edu.ph</a>
              </div>
            </div>
            <div class="col-md-4 ">
              <div class="form-group">
                <a href="tel:Phone: (032) 232 2642 / (032) 232 8185" target="_blank" id="yui_3_17_2_1_1616045956450_20"><i class="bi bi-telephone-fill"></i> (032) 232 2642 / (032) 232 8185</a>
              </div>
            </div>
          </div>
        </div>
      </div>


    </section>
    <script src="<?=base_url()?>/public/js/jquery/jquery-3.6.0.min.js"></script>
    <script src="<?=base_url()?>/public/js/bootstrap-4.6.0/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url()?>/public/js/bootstrap-4.6.0/bootstrap.min.js"></script>
    <script src="<?=base_url()?>/public/js/datatables/jquery.dataTables.min.js"></script>
    <script src="<?=base_url()?>/public/js/alertify/alertify.min.js"></script>
    <script src="<?=base_url()?>/public/js/image-picker/image-picker.min.js"></script>
    <script src="<?=base_url()?>/public/js/css-element-queries/src/ResizeSensor.js"></script>

    <script>
        // overried defaults of alertify
        alertify.defaults.theme.ok = "btn btn-primary";
        alertify.defaults.glossary.ok = "Dismiss";
        alertify.defaults.theme.cancel = "btn btn-danger";

        var BASE_URI = "<?=base_url();?>";
        var CURRENT_URI = "<?=uri_string();?>";
    </script>

    <script src="<?=base_url()?>/public/js/custom/common.js"></script>

    <?php if(isset($js)):?>
      <?= echoFiles($js);?>
    <?php endif;?>
  </body>
</html>
