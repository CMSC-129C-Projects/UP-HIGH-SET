// $(function(){
//     $('#btn-admin').addClass('active');

//     $('#btn-admin').click(function(){
//         if ($('#btn-student').hasClass('active')) {
//             $('#btn-student').removeClass('active');
//         }
//         $(this).addClass('active');
//         if ($('#Student').hasClass('active')) {
//             $('#Student').removeClass('active');
//         }
//         $('#Admin').addClass('active');
//         $('#Admin').addClass('show');
//     });

//     $('#btn-student').click(function(){
//         if ($('#btn-admin').hasClass('active')) {
//             $('#btn-admin').removeClass('active');
//         }
//         $(this).addClass('active');
//         if ($('#Admin').hasClass('active')) {
//             $('#Admin').removeClass('active');
//         }
//         $('#Student').addClass('active');
//         $('#Student').addClass('show');
//     });
// });