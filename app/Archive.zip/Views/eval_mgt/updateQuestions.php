<?= $this->extend('template/pageTemplate');?>

<?= $this->section('content');?>
<?= $this->endSection();?>