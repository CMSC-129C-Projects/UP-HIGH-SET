<?php

  echo "email template for carbon copy of the evaluation that was submitted by the student";
